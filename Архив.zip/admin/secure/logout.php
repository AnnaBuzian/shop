<?php
require "secure.inc.php";
logOut();
exit;